README for Alex Shoop CS 3516 Project 3

To compile:
make

To clean:
make clean

To run:
./project3
Then type in a trace level, such as 0 or 1.

Within the .c files of node0, node1, node2, and node3, the routines of rtinitN() and rtupdateN() (where N is 0, 1, 2, or 3)
are pretty much the same. I only changed the values of N within the respective routines.
